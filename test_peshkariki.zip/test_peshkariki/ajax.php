<?php
require_once 'Candidate.php';

$candidate = new Candidate();
$candidate->run();